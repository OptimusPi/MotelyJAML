using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Motely;

public struct MotelySingleSpectralStream(
    string resampleKey,
    MotelySingleResampleStream resampleStream,
    MotelySinglePrngStream blackHoleStream
)
{
    public readonly bool IsNull => ResampleKey == null;
    public readonly string ResampleKey = resampleKey;
    public MotelySingleResampleStream ResampleStream = resampleStream;
    public MotelySinglePrngStream SoulBlackHolePrngStream = blackHoleStream;
    public readonly bool IsSoulBlackHoleable => !SoulBlackHolePrngStream.IsInvalid;
}

public partial class MotelySingleSearchContext
{
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private MotelySingleSpectralStream CreateSpectralStream(
        string source,
        int ante,
        bool searchSpectral,
        bool soulBlackHoleable,
        bool isCached
    )
    {
        return new(
            MotelyPrngKeys.Spectral + source + ante,
            searchSpectral
                ? CreateResampleStream(MotelyPrngKeys.Spectral + source + ante, isCached)
                : MotelySingleResampleStream.Invalid,
            soulBlackHoleable
                ? CreatePrngStream(
                    MotelyPrngKeys.SpectralSoulBlackHole + MotelyPrngKeys.Spectral + ante,
                    isCached
                )
                : MotelySinglePrngStream.Invalid
        );
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public MotelySingleSpectralStream CreateSpectralPackSpectralStream(
        int ante,
        bool soulOnly = false,
        bool isCached = false
    ) =>
        CreateSpectralStream(
            MotelyPrngKeys.SpectralPackItemSource,
            ante,
            !soulOnly,
            true,
            isCached
        );

    /// <summary>
    /// Spectral cards generated inside Arcana packs under Omen Globe (create_card type Spectral
    /// in Arcana pack area). Uses Arcana pack item source so keys stay distinct from Spectral packs.
    /// </summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public MotelySingleSpectralStream CreateArcanaOmenSpectralStream(
        int ante,
        bool isCached = false
    ) =>
        CreateSpectralStream(
            MotelyPrngKeys.ArcanaPackItemSource,
            ante,
            searchSpectral: true,
            soulBlackHoleable: true,
            isCached
        );

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public MotelySingleSpectralStream CreateShopSpectralStream(int ante, bool isCached = false) =>
        CreateSpectralStream(MotelyPrngKeys.ShopItemSource, ante, true, false, isCached);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public MotelySingleSpectralStream CreateSixthSenseSpectralStream(
        int ante,
        bool isCached = false
    ) => CreateSpectralStream(MotelyPrngKeys.JokerSixthSense, ante, true, false, isCached);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public MotelySingleSpectralStream CreateSeanceSpectralStream(int ante, bool isCached = false) =>
        CreateSpectralStream(MotelyPrngKeys.JokerSeance, ante, true, false, isCached);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public bool GetNextSpectralPackHasTheSoul(
        ref MotelySingleSpectralStream spectralStream,
        MotelyBoosterPackSize size
    )
    {
        Debug.Assert(spectralStream.IsSoulBlackHoleable, "Spectral pack does not have the soul.");

        int cardCount = MotelyBoosterPackType.Spectral.GetCardCount(size);

        bool hasBlackHole = false;

        for (int i = 0; i < cardCount; i++)
        {
            if (GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997)
            {
                // We found the soul!

                // Progress the stream to get ready for the next pack
                for (; i < cardCount && !hasBlackHole; i++)
                {
                    hasBlackHole =
                        GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997;
                }
                return true;
            }

            if (!hasBlackHole && GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997)
            {
                hasBlackHole = true;
            }
        }

        return false;
    }

    public MotelySingleItemSet GetNextSpectralPackContents(
        ref MotelySingleSpectralStream spectralStream,
        MotelyBoosterPackSize size
    ) =>
        GetNextSpectralPackContents(
            ref spectralStream,
            MotelyBoosterPackType.Spectral.GetCardCount(size)
        );

    public MotelySingleItemSet GetNextSpectralPackContents(
        ref MotelySingleSpectralStream spectralStream,
        int size
    )
    {
        Debug.Assert(size <= MotelySingleItemSet.MaxLength);

        MotelySingleItemSet pack = new();

        for (int i = 0; i < size; i++)
            pack.Append(GetNextSpectral(ref spectralStream, pack));

        return pack;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public MotelyItem GetNextSpectral(ref MotelySingleSpectralStream spectralStream)
    {
        if (spectralStream.IsSoulBlackHoleable)
        {
            if (GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997)
            {
                return MotelyItemType.TheSoul;
            }

            if (GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997)
            {
                return MotelyItemType.BlackHole;
            }
        }

        MotelyItemType Spectral =
            (MotelyItemType)MotelyItemTypeCategory.SpectralCard
            | (MotelyItemType)GetNextRandomInt(
                ref spectralStream.ResampleStream.InitialPrngStream,
                0,
                MotelyEnum<MotelySpectralCard>.ValueCount
            );

        int resampleCount = 0;

        while (true)
        {
            if (Spectral != MotelyItemType.TheSoul && Spectral != MotelyItemType.BlackHole)
            {
                return Spectral;
            }

            Spectral =
                (MotelyItemType)MotelyItemTypeCategory.SpectralCard
                | (MotelyItemType)GetNextRandomInt(
                    ref GetResamplePrngStream(
                        ref spectralStream.ResampleStream,
                        spectralStream.ResampleKey,
                        resampleCount
                    ),
                    0,
                    MotelyEnum<MotelySpectralCard>.ValueCount
                );

            ++resampleCount;
        }
    }

    public MotelyItem GetNextSpectral(
        ref MotelySingleSpectralStream spectralStream,
        in MotelySingleItemSet itemSet
    )
    {
        if (spectralStream.IsSoulBlackHoleable)
        {
            if (
                !itemSet.Contains(MotelyItemType.TheSoul)
                && GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997
            )
            {
                return MotelyItemType.TheSoul;
            }

            if (
                !itemSet.Contains(MotelyItemType.BlackHole)
                && GetNextRandom(ref spectralStream.SoulBlackHolePrngStream) > 0.997
            )
            {
                return MotelyItemType.BlackHole;
            }
        }

        MotelyItemType Spectral =
            (MotelyItemType)MotelyItemTypeCategory.SpectralCard
            | (MotelyItemType)GetNextRandomInt(
                ref spectralStream.ResampleStream.InitialPrngStream,
                0,
                MotelyEnum<MotelySpectralCard>.ValueCount
            );

        int resampleCount = 0;

        while (true)
        {
            if (
                !itemSet.Contains(Spectral)
                && Spectral != MotelyItemType.TheSoul
                && Spectral != MotelyItemType.BlackHole
            )
            {
                return Spectral;
            }

            Spectral =
                (MotelyItemType)MotelyItemTypeCategory.SpectralCard
                | (MotelyItemType)GetNextRandomInt(
                    ref GetResamplePrngStream(
                        ref spectralStream.ResampleStream,
                        spectralStream.ResampleKey,
                        resampleCount
                    ),
                    0,
                    MotelyEnum<MotelySpectralCard>.ValueCount
                );

            ++resampleCount;
        }
    }
}
